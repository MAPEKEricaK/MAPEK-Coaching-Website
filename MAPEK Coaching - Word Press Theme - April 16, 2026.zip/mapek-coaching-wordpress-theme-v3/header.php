<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header" id="top">
  <div class="container nav-wrap">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="MAPEK Coaching home">
      <img class="logo-img" src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt="MAPEK Coaching logo">
    </a>

    <button class="nav-toggle" id="navToggle" aria-expanded="false" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>

    <nav class="site-nav" id="siteNav">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'active' : ''; ?>">Home</a>
      <a href="<?php echo esc_url(home_url('/about/')); ?>" class="<?php echo (is_page('about') || is_page_template('template-about.php')) ? 'active' : ''; ?>">About</a>
      <a href="<?php echo esc_url(home_url('/services/')); ?>" class="<?php echo (is_page('services') || is_page_template('template-services.php')) ? 'active' : ''; ?>">Services</a>
      <a href="<?php echo esc_url(home_url('/approach/')); ?>" class="<?php echo (is_page('approach') || is_page_template('template-approach.php')) ? 'active' : ''; ?>">Approach</a>
      <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="<?php echo (is_page('contact') || is_page_template('template-contact.php')) ? 'active' : ''; ?>">Contact</a>
      <a class="btn btn-primary nav-btn" href="<?php echo esc_url(mapek_booking_url()); ?>">Book a Chemistry Session</a>
    </nav>
  </div>
</header>
<main>
