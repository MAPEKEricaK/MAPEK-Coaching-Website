<?php
/*
Template Name: Services Page
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="section inner-hero">
  <div class="ambient ambient-two"></div>
  <div class="container narrow center">
    <p class="eyebrow">Services</p>
    <h1 class="inner-title"><?php echo esc_html(get_the_excerpt() ? get_the_excerpt() : get_the_title()); ?></h1>
    <p class="section-sub">There’s no single way to do this work. These are starting points — shape the rest around your needs.</p>
  </div>
</section>
<section class="section">
  <div class="container entry-content">
    <?php the_content(); ?>
  </div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
