<?php
function mapek_coaching_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('editor-styles');
}
add_action('after_setup_theme', 'mapek_coaching_theme_setup');

function mapek_coaching_enqueue_assets() {
    wp_enqueue_style('mapek-google-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@300;400;500;600&display=swap', array(), null);
    wp_enqueue_style('mapek-style', get_stylesheet_uri(), array('mapek-google-fonts'), '2.0');
    wp_enqueue_script('mapek-script', get_template_directory_uri() . '/script.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'mapek_coaching_enqueue_assets');

function mapek_booking_url() {
    return 'https://outlook.office.com/book/MAPEKConsultingMeetingswithErica@kohos.me/?ismsaljsauthenabled';
}

function mapek_email_url() {
    return 'mailto:erica@kohos.me?subject=Coaching Inquiry';
}

function mapek_page_url_shortcode($atts = array()) {
    $atts = shortcode_atts(array(
        'slug' => '',
    ), $atts, 'mapek_page_url');

    if (empty($atts['slug'])) {
        return home_url('/');
    }

    $page = get_page_by_path(sanitize_title($atts['slug']));
    if ($page instanceof WP_Post) {
        return get_permalink($page);
    }

    return home_url('/' . sanitize_title($atts['slug']) . '/');
}
add_shortcode('mapek_page_url', 'mapek_page_url_shortcode');

function mapek_booking_url_shortcode() {
    return esc_url(mapek_booking_url());
}
add_shortcode('mapek_booking_url', 'mapek_booking_url_shortcode');

function mapek_email_url_shortcode() {
    return esc_url(mapek_email_url());
}
add_shortcode('mapek_email_url', 'mapek_email_url_shortcode');

function mapek_body_classes($classes) {
    $classes[] = 'page-body';

    if (is_front_page()) {
        $classes[] = 'home-page';
    } elseif (is_page('about') || is_page_template('template-about.php')) {
        $classes[] = 'about-page';
    } elseif (is_page('services') || is_page_template('template-services.php')) {
        $classes[] = 'services-page';
    } elseif (is_page('approach') || is_page_template('template-approach.php')) {
        $classes[] = 'approach-page';
    } elseif (is_page('contact') || is_page_template('template-contact.php')) {
        $classes[] = 'contact-page';
    }

    return $classes;
}
add_filter('body_class', 'mapek_body_classes');

function mapek_template_for_slug($slug) {
    $map = array(
        'home' => 'template-home.php',
        'about' => 'template-about.php',
        'services' => 'template-services.php',
        'approach' => 'template-approach.php',
        'contact' => 'template-contact.php',
    );

    return isset($map[$slug]) ? $map[$slug] : 'page.php';
}

function mapek_default_pages() {
    return array(
        'home' => array(
            'title' => 'Leadership and growth, on your terms.',
            'excerpt' => 'Strategic, deeply personal coaching for leaders and professionals who want to think clearly, challenge themselves honestly, and grow in a way that actually fits.',
            'template' => 'template-home.php',
            'content' => <<<'HTML'
<div class="services-band glass-panel depth-panel">
  <article>
    <h3>1:1 Leadership</h3>
    <p>Personalized coaching for growth, transition, and stepping into bigger roles with more confidence.</p>
  </article>
  <article>
    <h3>Team Coaching</h3>
    <p>Thoughtful support for teams navigating change, communication, and evolving expectations.</p>
  </article>
  <article>
    <h3>Executive Focused</h3>
    <p>Strategic partnership for thoughtful professionals leading through complexity, influence, and change.</p>
  </article>
</div>

<div class="cards three">
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">About</span>
    <h3>Erica’s perspective</h3>
    <p>A non-linear path, systems thinking, and a deeply human approach to growth.</p>
    <a class="text-link" href="[mapek_page_url slug='about']">Read Erica’s story</a>
  </article>
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">Services</span>
    <h3>How we work together</h3>
    <p>Three ways to get the right kind of support, depending on where you are.</p>
    <a class="text-link" href="[mapek_page_url slug='services']">Explore ways to work together</a>
  </article>
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">Approach</span>
    <h3>Beyond generic advice</h3>
    <p>Reflect, reframe, realign, and move forward with clarity.</p>
    <a class="text-link" href="[mapek_page_url slug='approach']">See the approach</a>
  </article>
</div>
HTML
        ),
        'about' => array(
            'title' => 'About Erica',
            'excerpt' => 'Growth is rarely linear. Leadership is even less so.',
            'template' => 'template-about.php',
            'content' => <<<'HTML'
<div class="split">
  <div class="glass-panel depth-panel card">
    <p>Erica’s path has crossed disciplines, industries, and life chapters — from supporting neurodivergent children and families, to policy and transformation roles across government and private enterprise, to co-founding a consultancy while raising a family.</p>
    <p>If you’ve ever felt like most advice doesn’t quite land — or that you’ve had to figure things out your own way — you’re not alone.</p>
    <p>Through all of it, one truth has remained constant: generic advice rarely works in the real world.</p>
    <p>Real growth requires space — space to think clearly, to be honest with yourself, and to build a path that actually fits.</p>
    <p>Today, Erica brings that perspective into her work with leaders, high performers, and teams navigating complexity, transition, and what comes next.</p>
    <p>Her approach is thoughtful, strategic, and deeply human.</p>
    <blockquote>“You can’t force someone to grow unless they are ready and willing.”</blockquote>
  </div>
  <aside class="card glass-panel depth-panel">
    <p class="eyebrow">Why people choose this work</p>
    <ul class="clean-list">
      <li>To think clearly in the middle of complexity</li>
      <li>To hear their own thinking reflected back with clarity</li>
      <li>To gain perspective without being handed generic advice</li>
      <li>To build momentum through honesty and accountability</li>
      <li>To grow in a way that actually fits who they are</li>
    </ul>
  </aside>
</div>
HTML
        ),
        'services' => array(
            'title' => 'Services',
            'excerpt' => 'Support that meets you where you are.',
            'template' => 'template-services.php',
            'content' => <<<'HTML'
<div class="cards three">
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">1:1 Coaching</span>
    <h3>Momentum</h3>
    <p>A tailored coaching partnership for leaders and professionals navigating growth, transition, or increased responsibility.</p>
    <ul class="clean-list compact">
      <li>Typically offered as a 3- or 6-month engagement</li>
      <li>Strategic, reflective, and deeply personal support</li>
      <li>Built around your context, pace, and goals</li>
    </ul>
    <p class="micro-note">We adjust the pace, focus, and structure as we go.</p>
  </article>
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">Focused Session</span>
    <h3>Clarity Session</h3>
    <p>A focused one-time session for a decision, leadership moment, or strategic crossroads that needs real thinking space.</p>
    <ul class="clean-list compact">
      <li>Fast perspective with thoughtful, focused support</li>
      <li>Ideal before or between larger engagements</li>
      <li>Leaves you with clarity and concrete next steps</li>
    </ul>
  </article>
  <article class="card service-card glass-panel depth-panel">
    <span class="card-tag">Teams &amp; Leaders</span>
    <h3>Growth Lab</h3>
    <p>Leadership and team development designed for organizations navigating communication, change, and evolving expectations.</p>
    <ul class="clean-list compact">
      <li>Workshops, group sessions, or targeted coaching</li>
      <li>Built around real organizational context</li>
      <li>Especially valuable for transformation-minded teams</li>
    </ul>
  </article>
</div>
HTML
        ),
        'approach' => array(
            'title' => 'Approach',
            'excerpt' => 'Beyond generic advice.',
            'template' => 'template-approach.php',
            'content' => <<<'HTML'
<div class="steps">
  <article class="step glass-panel depth-panel"><span>01</span><h3>Reflect</h3><p>Notice patterns, blind spots, tensions, and what is sitting just underneath the surface.</p></article>
  <article class="step glass-panel depth-panel"><span>02</span><h3>Reframe</h3><p>Ask creative questions and reflect ideas back in a way that opens new perspective and possibility.</p></article>
  <article class="step glass-panel depth-panel"><span>03</span><h3>Realign</h3><p>Build strategies that fit your responsibilities, strengths, and way of working.</p></article>
  <article class="step glass-panel depth-panel"><span>04</span><h3>Move</h3><p>Create accountability, clarity, and practical next steps that can actually hold in real life.</p></article>
</div>
HTML
        ),
        'contact' => array(
            'title' => 'Contact',
            'excerpt' => 'Let’s create real momentum.',
            'template' => 'template-contact.php',
            'content' => <<<'HTML'
<div class="contact-grid">
  <article class="card glass-panel depth-panel contact-card contact-primary">
    <p class="card-tag">Work Together</p>
    <h3>Chemistry Session</h3>
    <p>The best first step is a conversation to see if we’re a good fit. Use the booking page to choose a time that works for you.</p>
    <div class="contact-actions">
      <a class="btn btn-primary" href="[mapek_booking_url]">Book a chemistry session</a>
    </div>
    <p class="micro-note">A short, thoughtful conversation to explore fit.</p>
  </article>

  <article class="card glass-panel depth-panel contact-card">
    <p class="card-tag">Prefer email?</p>
    <h3>Email Erica directly</h3>
    <p>If you’d rather reach out personally first, send an email and share a bit about what you’re looking for.</p>
    <div class="contact-actions">
      <a class="btn btn-secondary gradient-secondary" href="[mapek_email_url]">Email Erica</a>
    </div>
  </article>
</div>
HTML
        ),
    );
}

function mapek_create_or_update_default_pages() {
    $pages = mapek_default_pages();
    $front_page_id = 0;

    foreach ($pages as $slug => $page_data) {
        $existing_page = get_page_by_path($slug);
        $postarr = array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_name' => $slug,
            'post_title' => $page_data['title'],
            'post_excerpt' => $page_data['excerpt'],
        );

        if ($existing_page instanceof WP_Post) {
            $page_id = $existing_page->ID;
        } else {
            $postarr['post_content'] = $page_data['content'];
            $page_id = wp_insert_post($postarr);
        }

        if (!is_wp_error($page_id) && $page_id) {
            update_post_meta($page_id, '_wp_page_template', $page_data['template']);
            if ($slug === 'home') {
                $front_page_id = $page_id;
            }
        }
    }

    if ($front_page_id) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $front_page_id);
    }
}

function mapek_after_switch_theme() {
    mapek_create_or_update_default_pages();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'mapek_after_switch_theme');
