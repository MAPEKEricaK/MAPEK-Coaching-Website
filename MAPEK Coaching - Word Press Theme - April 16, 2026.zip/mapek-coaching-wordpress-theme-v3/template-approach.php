<?php
/*
Template Name: Approach Page
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="section inner-hero">
  <div class="ambient ambient-one"></div>
  <div class="container narrow center">
    <p class="eyebrow">Approach</p>
    <h1 class="inner-title"><?php echo esc_html(get_the_excerpt() ? get_the_excerpt() : get_the_title()); ?></h1>
    <p class="section-sub">This is coaching for people who want a real thinking partner — someone who can hold thoughtful space and help translate insight into action.</p>
  </div>
</section>
<section class="section">
  <div class="container entry-content">
    <?php the_content(); ?>
  </div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
