<?php
/*
Template Name: About Page
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="section inner-hero">
  <div class="ambient ambient-one"></div>
  <div class="container narrow center">
    <p class="eyebrow">About Erica</p>
    <h1 class="inner-title"><?php echo esc_html(get_the_excerpt() ? get_the_excerpt() : get_the_title()); ?></h1>
  </div>
</section>
<section class="section">
  <div class="container entry-content">
    <?php the_content(); ?>
  </div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
