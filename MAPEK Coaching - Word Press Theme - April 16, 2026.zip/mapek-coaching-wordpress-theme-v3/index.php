<?php get_header(); ?>
<section class="section inner-hero">
  <div class="container narrow center">
    <p class="eyebrow"><?php echo is_home() ? 'Latest Posts' : 'Page'; ?></p>
    <h1 class="inner-title"><?php echo is_home() ? 'Latest Posts' : 'Content'; ?></h1>
  </div>
</section>
<section class="section">
  <div class="container narrow">
    <div class="card glass-panel depth-panel entry-content">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class(); ?>>
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <?php the_content(); ?>
        </article>
      <?php endwhile; else : ?>
        <p>This page is ready to be customized in WordPress.</p>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php get_footer(); ?>
