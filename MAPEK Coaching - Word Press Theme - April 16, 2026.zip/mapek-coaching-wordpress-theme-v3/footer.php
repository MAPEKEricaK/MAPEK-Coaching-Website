</main>
<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <div class="brand footer-brand">
        <img class="logo-img footer-logo" src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt="MAPEK Coaching logo">
      </div>
      <p class="footer-copy">Strategic, deeply personal coaching for leaders, professionals, and teams ready to grow on their own terms.</p>
    </div>
    <div class="footer-links">
      <a href="<?php echo esc_url(home_url('/about/')); ?>">About</a>
      <a href="<?php echo esc_url(home_url('/services/')); ?>">Services</a>
      <a href="<?php echo esc_url(home_url('/approach/')); ?>">Approach</a>
      <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
    </div>
  </div>
  <div class="footer-sub">MAPEK Coaching, a child brand of MAPEK Consulting</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
