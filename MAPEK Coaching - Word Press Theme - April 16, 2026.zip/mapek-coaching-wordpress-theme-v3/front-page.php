<?php
get_header();

if (have_posts()) :
    while (have_posts()) : the_post();
        $page_id = get_the_ID();
        $headline = get_the_title();
        $subheadline = has_excerpt() ? get_the_excerpt() : 'Strategic, deeply personal coaching for leaders and professionals ready to grow with clarity, honesty, and momentum.';
        ?>
        <section class="hero page-hero">
          <div class="ambient ambient-one"></div>
          <div class="ambient ambient-two"></div>
          <div class="container hero-grid">
            <div class="hero-copy">
              <div class="pill"><?php echo esc_html(get_bloginfo('name')); ?></div>
              <h1><?php echo wp_kses_post(nl2br(esc_html($headline))); ?></h1>
              <p class="hero-sub"><?php echo esc_html($subheadline); ?></p>
              <div class="hero-actions">
                <a class="btn btn-primary" href="<?php echo esc_url(mapek_booking_url()); ?>">Book a Chemistry Session</a>
                <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Services</a>
              </div>
              <p class="hero-note">Edit this page in WordPress Pages to update the homepage copy and cards.</p>
            </div>
          </div>
        </section>

        <section class="section preview-section">
          <div class="container page-content entry-content">
            <?php echo apply_filters('the_content', get_post_field('post_content', $page_id)); ?>
          </div>
        </section>
        <?php
    endwhile;
else :
    ?>
    <section class="section">
      <div class="container narrow">
        <div class="card glass-panel depth-panel">
          <p>Create a page, assign it as the homepage, and add your content in Pages &gt; All Pages.</p>
        </div>
      </div>
    </section>
    <?php
endif;

get_footer();
