<?php
/*
Template Name: Contact Page
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="section inner-hero">
  <div class="ambient ambient-two"></div>
  <div class="container narrow center">
    <p class="eyebrow">Contact</p>
    <h1 class="inner-title"><?php echo esc_html(get_the_excerpt() ? get_the_excerpt() : get_the_title()); ?></h1>
    <p class="section-sub">Start with a conversation. There’s no pressure — just a chance to see if this feels like the right fit.</p>
  </div>
</section>
<section class="section contact-experience">
  <div class="container entry-content">
    <?php the_content(); ?>
  </div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
