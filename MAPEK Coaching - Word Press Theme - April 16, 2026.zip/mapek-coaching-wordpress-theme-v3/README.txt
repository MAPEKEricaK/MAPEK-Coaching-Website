MAPEK Coaching Premium WordPress Theme

What changed:
- Converted the theme to use real WordPress Pages.
- Added a standard page.php plus dedicated page templates for Home, About, Services, Approach, and Contact.
- Removed the virtual rewrite/routing setup so content now lives in editable WordPress pages.
- On theme activation, the theme creates starter pages (if they do not already exist), assigns the matching templates, and sets Home as the static front page.

How to use:
1. In WordPress admin go to Appearance > Themes > Add New > Upload Theme.
2. Upload this ZIP and activate it.
3. Go to Pages > All Pages.
4. Edit Home, About, Services, Approach, or Contact to change the copy.
5. The page title and excerpt control the hero text on most templates.

Notes:
- Existing pages are not overwritten; starter content is only inserted when a page does not already exist.
- The homepage buttons still use the built-in booking URL and Services page link.
- Shortcodes available in page content:
  - [mapek_booking_url]
  - [mapek_email_url]
  - [mapek_page_url slug="about"]
