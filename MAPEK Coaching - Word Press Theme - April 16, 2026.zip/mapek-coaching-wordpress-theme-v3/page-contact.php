<?php
require get_template_directory() . '/template-contact.php';
