<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="section inner-hero">
  <div class="container narrow center">
    <p class="eyebrow"><?php echo esc_html(get_the_title()); ?></p>
    <h1 class="inner-title"><?php echo esc_html(get_the_title()); ?></h1>
    <?php if (has_excerpt()) : ?>
      <p class="section-sub"><?php echo esc_html(get_the_excerpt()); ?></p>
    <?php endif; ?>
  </div>
</section>

<section class="section">
  <div class="container narrow entry-content">
    <div class="card glass-panel depth-panel">
      <?php the_content(); ?>
    </div>
  </div>
</section>
<?php endwhile; else : ?>
<section class="section">
  <div class="container narrow">
    <div class="card glass-panel depth-panel">
      <p>This page is ready to be customized in WordPress.</p>
    </div>
  </div>
</section>
<?php endif; ?>
<?php get_footer(); ?>
