<?php
/*
Template Name: Home Page
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<section class="hero page-hero">
  <div class="ambient ambient-one"></div>
  <div class="ambient ambient-two"></div>
  <div class="container hero-grid">
    <div class="hero-copy">
      <div class="pill"><?php echo esc_html(get_bloginfo('name')); ?></div>
      <h1><?php echo esc_html(get_the_title()); ?></h1>
      <?php if (has_excerpt()) : ?>
        <p class="hero-sub"><?php echo esc_html(get_the_excerpt()); ?></p>
      <?php endif; ?>
      <div class="hero-actions">
        <a class="btn btn-primary" href="<?php echo esc_url(mapek_booking_url()); ?>">Book a Chemistry Session</a>
        <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Services</a>
      </div>
      <p class="hero-note">Edit this page in Pages &gt; All Pages to update the homepage copy.</p>
    </div>
  </div>
</section>
<section class="section preview-section">
  <div class="container page-content entry-content">
    <?php the_content(); ?>
  </div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
